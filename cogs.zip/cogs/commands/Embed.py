import os
import discord
from discord.ext import commands
from discord.ui import View, Button

class Embed(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.client = bot

    @commands.hybrid_command(name="embed")
    async def _embed(self, ctx):
        msgx = "This is an example embed. You can customize everything."
        embed = discord.Embed(description="ok", color=0x2f3136)

        def chk(m):
            return m.channel.id == ctx.channel.id and m.author.id == ctx.author.id and not m.author.bot

        async def button_cal(interaction):
            try:
                await ctx.send("Please enter the title of the embed.")
                tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
                embed.title = tit.content
                await ctx.message.edit(content=msgx, embed=embed)
            except Exception as e:
                print(e)
                await ctx.send("Timed Out")

        async def button_call(interaction):
            tit = ""
            try:
                await ctx.send("Please enter the description of the embed.")
                tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
            except Exception as e:
                print(e)
                await ctx.send("Timed Out")
            embed.description = tit.content
            await ctx.message.edit(content=msgx, embed=embed)

        async def button_calll(interaction):
            tit = ""
            try:
                await ctx.send("Please enter the color of the embed. You can use a hex value or a color name.")
                tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
            except Exception as e:
                print(e)
                await ctx.send("Timed Out")
            
            color_input = tit.content.lower()
            color_value = 0x2f3136  # Default color if the user input is invalid
            
            # Try to parse the color value from the input
            if color_input.startswith("#") and len(color_input) == 7:
                try:
                    color_value = int(color_input[1:], 16)
                except ValueError:
                    pass
            else:
                color_names = {
                    "red": 0xFF0000,
                    "green": 0x00FF00,
                    "blue": 0x0000FF,
                    "yellow": 0xFFFF00,
                    "orange": 0xFFA500,
                }
                color_value = color_names.get(color_input, color_value)

            embed.color = color_value
            await ctx.message.edit(content=msgx, embed=embed)

        async def button_callll(interaction):
            tit = ""
            try:
                await ctx.send("Please enter the url of the thumbnail.")
                tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
            except Exception as e:
                print(e)
                await ctx.send("Timed Out")
            embed.set_thumbnail(url=tit.content)
            await ctx.message.edit(content=msgx, embed=embed)

        async def button_calllll(interaction):
            tit = ""
            try:
                await ctx.send("Please enter the url of the image.")
                tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
            except Exception as e:
                print(e)
                await ctx.send("Timed Out")
            embed.set_image(url=tit.content)
            await ctx.message.edit(content=msgx, embed=embed)

        async def button_callllll(interaction):
            tit = ""
            try:
                await ctx.send("Please enter the text of the footer.")
                tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
            except Exception as e:
                print(e)
                await ctx.send("Timed Out")
            embed.set_footer(text=tit.content)
            await ctx.message.edit(content=msgx, embed=embed)

        async def button_callllllll(interaction):
            tit = ""
            try:
                await ctx.send("Please mention the channel where you want to send this embed.")
                tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
            except Exception as e:
                print(e)
                await ctx.send("Timed Out")
            chnl = tit.channel_mentions[0]
            await chnl.send(embed=embed)
            await ctx.send("Sent")

        # Assign the updated row values
        button1 = Button(label="Title", style=discord.ButtonStyle.green, row=1)
        button1.callback = button_cal

        button2 = Button(label="Description", style=discord.ButtonStyle.green, row=2)
        button2.callback = button_call

        button3 = Button(label="Color", style=discord.ButtonStyle.green, row=3)
        button3.callback = button_calll

        button4 = Button(label="Thumbnail", style=discord.ButtonStyle.green, row=4)
        button4.callback = button_callll

        button5 = Button(label="Image", style=discord.ButtonStyle.green, row=5)
        button5.callback = button_calllll

        button6 = Button(label="Footer", style=discord.ButtonStyle.green, row=6)
        button6.callback = button_callllll

        button7 = Button(label="Send", style=discord.ButtonStyle.blurple, row=7)
        button7.callback = button_callllllll

        LING = View()
        buttons = [button1, button2, button3, button4, button5, button6, button7]
        for pp in buttons:
            LING.add_item(pp)

        msg = await ctx.send(embed=embed, content=msgx, view=LING)
        ctx.message = msg

def setup(bot):
    bot.add_cog(Embed(bot))
