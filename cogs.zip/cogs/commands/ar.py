import discord
from discord.ext import commands


class ar(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """AutoResponse commands"""
  
    def help_custom(self):
		      emoji = '<:anxAutoresponder:1137197782202073118>'
		      label = "AutoResponse"
		      description = "Show You AutoResponse Commands"
		      return emoji, label, description

    @commands.group()
    async def __AutoResponse__(self, ctx: commands.Context):
        """`autoresponse`, `autoresponse config`, `autoresponse delete`, `autoresponse create`, `autoresponse edit`"""