import discord
from discord.ext import commands

class fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Fun commands"""

    def help_custom(self):
        emoji = '<:anxLeo:1137197656268095529>'
        label = "Fun"
        description = "Show You Fun Commands"
        return emoji, label, description

    @commands.group()
    async def Fun(self, ctx: commands.Context):
        """`tickle`, `kiss`, `hug`, `slap`, `pat`, `feed`, `pet`, `howgay`, `slots`, `penis`, `meme`, `cat`, `iplookup`"""
