import discord
from discord.ext import commands


class vanity(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Vanity commands"""
  
    def help_custom(self):
		      emoji = '<:anxWelcome:1137197708629778452>'
		      label = "Vanity Role"
		      description = "Show You Vanity Commands"
		      return emoji, label, description

    @commands.group()
    async def __vanityrole__(self, ctx: commands.Context):
        """ `vanity set`, `vanity message`, `vanity channel`, `vanity role`, `vanity clear`"""