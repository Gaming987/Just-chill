import discord
from discord.ext import commands


class ticket(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Ticket commands"""
  
    def help_custom(self):
		      emoji = '<:anxTicket:1137197756172214352>'
		      label = "Ticket"
		      description = "Show You Ticket Commands"
		      return emoji, label, description

    @commands.group()
    async def __Ticket__(self, ctx: commands.Context):
        """`sendpanel`"""