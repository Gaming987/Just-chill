import discord
from discord.ext import commands


class automod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Raidmode commands"""
  
    def help_custom(self):
		      emoji = '<:banHammer:1137197405268361268>'
		      label = "Raidmode"
		      description = "Show You Raidmode Commands"
		      return emoji, label, description

    @commands.group()
    async def __Raidmode__(self, ctx: commands.Context):
        """<:anxSettings:1137400838285971526> **__AutoModeration__**
        `automod` , `antispam on` , `antispam off` , `antilink off` ,  `antilink on`
        
        <:anxSettings:1137400838285971526> **__Logging__**
        `logall enable`, `logall disable`"""